this is example where you want to divert all tranfic for endpoint ending with f1 to a different backend
