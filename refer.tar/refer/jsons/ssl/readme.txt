for SSL you will need to paste /home/ubuntu/haproxy_config/refer/template/forSSL/haproxy_cfg.template to /home/ubuntu/haproxy_config/resources/templates

also make sure to edit line bind {{BindIp}} {{BindPort}} ssl crt <certificate location>
