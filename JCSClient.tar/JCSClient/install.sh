#!/bin/bash

echo ""
echo ""
echo "Following packages will be installed "
echo "libgmp10_5.1.3+dfsg-1ubuntu1_amd64.deb"
echo "python-crypto_2.6.1-4build1_amd64.deb"
echo "python-jcsclient_2.1.0_all.deb"
echo "python-requests_2.2.1-1ubuntu0.3_all.deb"
echo "python-six_1.5.2-1_all.deb"
echo "python-xmltodict_0.9.0-1_all.deb"
echo "python-yaml_3.10-4build4_amd64.deb"
echo ""
echo ""

echo "Do you wish to install JCS-CLI"
echo ""
echo "enter 1 for yes "
echo "enter 2 for no "
echo ""

select yn in "yes" "no" ; do
    case $yn in 
        yes ) dpkg -i libgmp10_5.1.3+dfsg-1ubuntu1_amd64.deb;dpkg -i python-crypto_2.6.1-4build1_amd64.deb;dpkg -i python-requests_2.2.1-1ubuntu0.3_all.deb;dpkg -i python-six_1.5.2-1_all.deb;dpkg -i python-xmltodict_0.9.0-1_all.deb;dpkg -i python-yaml_3.10-4build4_amd64.deb;dpkg -i python-jcsclient_2.1.0_all.deb;break;;
        no ) exit ;;

    esac
done

